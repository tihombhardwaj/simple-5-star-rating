=== Simple 5 Star Rating ===
Tags: rating, rate post, star rating, google rating, votes, seo optimized rating, rating plugin, wordpress post rating system
Requires at least: 4.9.0
Contributors: Mohit Bhardwaj, Rajan Bhardwaj
Tested up to: 5.4.1
Requires PHP: 5.3
Stable tag: 2.3.3
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will help readers to interact with you by giving stars to your content. On the basis of star reviews you can plan your further writing content.

== Description ==
It will help your blog readers to share their reviews in the form of stars. Users can rate your blog posts 1 to 5 and on the basis of the rating you can imorove yourself or you can reward your authors.

Simple 5 Star Rating system is simple but powerful plugin it will place the stars in the bottom of your article so that just after finishing the reading users will see the rating system to rate.

= How To use =
It is a simple plugin. Simple Installation will make it working.

= Supported Languages =
Currently Supporting English Language Only.

== Installation ==
1. Install Simple 5 Star Rating via the WordPress.org plugin directory, or by uploading the files to your server.
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Now your job is done, it will work on its own.

== Frequently Asked Questions ==

= What is the maximum and minimum rating value? =
A user can give a maximum of 5 stars and minimum 1 star to your wordpress post.

= Does this plugin reloads page after rating is submitted? =
No, it won't reload the page. It uses javascripts/jQuery to update rating.
= Does it work with caching plugins? =
Yes, it works with caching plugins as it is using AJAX. So don't worry it will work fine with your cache plugins.


= 1.0 =
* Just lauched with basic but powerful rating facilites.
1. Every visitor (Either logged in or not) Can Vote on each post only once.
2. It tracks the IP Address of visitors rating you posts.
3. One visiter can give rating to a single post only once.
4. Ratings are dynamically loaded / updated hence it won't create problem with your cache plugin.